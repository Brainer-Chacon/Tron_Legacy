using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using tron;

public class Bomb
{
    public GridNode Position { get; private set; }
    public Rectangle Visual { get; private set; }
    public int ExplosionRadius { get; private set; } = 3; // Radio de explosión de 3x3
    private GameGrid _gameGrid;
    private bool _hasExploded; // Indica si la bomba ya ha explotado

    public Bomb(GridNode position, GameGrid gameGrid)
    {
        Position = position;
        _gameGrid = gameGrid;
        Visual = CreateVisual(); // Crear la representación visual de la bomba
        UpdateVisualPosition(); // Establecer la posición inicial del visual

       
    }

    private Rectangle CreateVisual()
    {
        return new Rectangle
        {
            Width = MainWindow.CellSize,
            Height = MainWindow.CellSize,
            Fill = Brushes.YellowGreen, // Color distintivo para la bomba
            Stroke = Brushes.Black,
            StrokeThickness = 1
        };
    }

    public void Explode()
    {
        if (!_hasExploded)
        {
            _hasExploded = true; // Marca la bomba como explotada

            // Obtener nodos afectados por la explosión
            var affectedNodes = GetAffectedNodes();

            foreach (var node in affectedNodes)
            {
                if (node.IsOccupied)
                {
                    // Destruir la moto en el nodo
                    DestroyMotoAtNode(node);
                }

                // Desocupar el nodo independientemente de si estaba ocupado o no
                _gameGrid.MarkAsUnoccupied(node);
            }

            // Eliminar la bomba del juego
            _gameGrid.RemoveItem(this);
        }
    }

    private List<GridNode> GetAffectedNodes()
    {
        var affectedNodes = new List<GridNode>();
        var centerNode = Position;

        for (int x = -ExplosionRadius; x <= ExplosionRadius; x++)
        {
            for (int y = -ExplosionRadius; y <= ExplosionRadius; y++)
            {
                // Verificar si la posición está dentro del rango del radio de explosión
                if (Math.Abs(x) + Math.Abs(y) <= ExplosionRadius)
                {
                    var node = _gameGrid.GetNodeAtPosition(centerNode.X + x, centerNode.Y + y);
                    if (node != null)
                    {
                        affectedNodes.Add(node);
                    }
                }
            }
        }

        return affectedNodes;
    }

    private void DestroyMotoAtNode(GridNode node)
    {
        var moto = _gameGrid.GetMotoAtNode(node);
        if (moto != null)
        {
            moto.EliminateLightCycle(); // Método para eliminar completamente la moto
        }
    }

    public void Respawn(GameGrid gameGrid)
    {
        // Libera la posición actual de la bomba
        Position.IsOccupied = false;

        Random random = new Random();
        int newRow, newCol;

        // Encuentra una nueva posición libre sin bombas, gasolina, ítems ni motos
        do
        {
            newRow = random.Next(0, gameGrid.Rows); // Genera fila aleatoria
            newCol = random.Next(0, gameGrid.Cols); // Genera columna aleatoria
        }
        // Verifica que la nueva posición no esté ocupada ni por bombas, ni por gasolina, ni por ítems ni por motos
        while (gameGrid.Grid[newRow, newCol].IsOccupied ||
               gameGrid.Grid[newRow, newCol].IsGasolineOccupied ||
               gameGrid.Grid[newRow, newCol].IsItemOccupied ||
               gameGrid.Grid[newRow, newCol].IsSpeedItemOccupied ||
               gameGrid.Grid[newRow, newCol].IsShieldOccupied);

        // Asigna la nueva posición a la bomba
        Position = gameGrid.Grid[newRow, newCol];
        Position.IsOccupied = false; // Marca la nueva posición como ocupada por la bomba

        // Actualiza la posición visual de la bomba
        UpdateVisualPosition();
    }

    public void UpdateVisualPosition()
    {
        Canvas.SetLeft(Visual, Position.Y * MainWindow.CellSize);
        Canvas.SetTop(Visual, Position.X * MainWindow.CellSize);
    }
}



