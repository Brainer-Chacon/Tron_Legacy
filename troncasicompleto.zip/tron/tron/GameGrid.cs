using System;
using System.Collections.Generic;

namespace tron
{
    public class GridNode
    {
        public GridNode Up { get; set; }
        public GridNode Down { get; set; }
        public GridNode Left { get; set; }
        public GridNode Right { get; set; }
        public items Item { get; set; }
        public GasolineItem GasolineItem { get; set; }

        public int X { get; set; } // Cambiado a X para coincidir con LightCycle
        public int Y { get; set; } // Cambiado a Y para coincidir con LightCycle
        public bool IsOccupied { get; set; } // Estado de ocupación del nodo
        public bool IsGasolineOccupied { get; set; } // Para los ítems de gasolina
        public bool IsItemOccupied { get; set; } // Propiedad para los ítems
        public bool IsSpeedItemOccupied { get; set; } // bool para velocidad
        public bool IsShieldOccupied { get; set; }

        public GridNode(int x, int y)
        {
            X = x;
            Y = y;
            IsOccupied = false; // Por defecto, el nodo no está ocupado
            IsGasolineOccupied = false;
            IsItemOccupied = false;
            IsSpeedItemOccupied = false;
            Item = null;
            GasolineItem = null;
        }
    }

    public class GameGrid
    {
        public int Rows { get; private set; }
        public int Cols { get; private set; }
        public GridNode[,] Grid { get; private set; }
        private List<LightCycle> _lightCycles; // Lista de motos en el juego

        public GameGrid(int rows, int cols)
        {
            Rows = rows;
            Cols = cols;
            Grid = new GridNode[rows, cols];
            _lightCycles = new List<LightCycle>(); // Inicializar la lista de motos
            InitializeGrid();
        }

        private void InitializeGrid()
        {
            for (int i = 0; i < Rows; i++)
            {
                for (int j = 0; j < Cols; j++)
                {
                    Grid[i, j] = new GridNode(i, j);

                    if (i > 0)
                    {
                        Grid[i, j].Up = Grid[i - 1, j];
                    }

                    if (i < Rows - 1)
                    {
                        Grid[i, j].Down = Grid[i + 1, j];
                    }

                    if (j > 0)
                    {
                        Grid[i, j].Left = Grid[i, j - 1];
                    }

                    if (j < Cols - 1)
                    {
                        Grid[i, j].Right = Grid[i, j + 1];
                    }
                }
            }
        }

        public GridNode GetNodeAtPosition(int row, int column)
        {
            if (row >= 0 && row < Rows && column >= 0 && column < Cols)
            {
                return Grid[row, column];
            }

            return null;
        }

        // Método para marcar un nodo como no ocupado
        public void MarkAsUnoccupied(GridNode node)
        {
            if (node != null && node.X >= 0 && node.X < Rows && node.Y >= 0 && node.Y < Cols)
            {
                Grid[node.X, node.Y].IsOccupied = false;
                Grid[node.X, node.Y].IsGasolineOccupied = false;
                Grid[node.X, node.Y].IsItemOccupied = false;
                Grid[node.X, node.Y].IsSpeedItemOccupied = false;
                Grid[node.X, node.Y].Item = null;
                Grid[node.X, node.Y].GasolineItem = null;
                // Aquí puedes agregar lógica para actualizar la interfaz gráfica si es necesario
            }
        }

        // Método para remover una lista de nodos del grid
        public void RemoveNodesFromGrid(List<GridNode> nodesAffected)
        {
            foreach (var node in nodesAffected)
            {
                if (node != null)
                {
                    MarkAsUnoccupied(node); // Marca el nodo como no ocupado
                }
            }
        }

        // Método para obtener la moto en un nodo específico
        public LightCycle GetMotoAtNode(GridNode node)
        {
            if (node != null)
            {
                foreach (var lightCycle in _lightCycles)
                {
                    if (lightCycle.Trail.Contains(node)) // Suponiendo que LightCycle tiene una lista de nodos en su estela
                    {
                        return lightCycle;
                    }
                }
            }
            return null;
        }

        public void AddLightCycle(LightCycle lightCycle)
        {
            if (lightCycle != null && !_lightCycles.Contains(lightCycle))
            {
                _lightCycles.Add(lightCycle);
            }
        }

        public void RemoveLightCycle(LightCycle lightCycle)
        {
            if (lightCycle != null && _lightCycles.Contains(lightCycle))
            {
                _lightCycles.Remove(lightCycle);
            }
        }

        public void RemoveItem(Bomb bomb)
        {
            if (bomb != null)
            {
                // Obtener nodos afectados por la explosión de la bomba
                var affectedNodes = GetAffectedNodes(bomb.Position);

                // Eliminar la bomba del grid
                foreach (var node in affectedNodes)
                {
                    if (node != null)
                    {
                        // Marca el nodo como no ocupado y limpia los ítems
                        MarkAsUnoccupied(node);
                    }
                }
            }
        }

        private List<GridNode> GetAffectedNodes(GridNode centerNode)
        {
            var affectedNodes = new List<GridNode>();
            int explosionRadius = 3; // Radio de explosión 3x3

            for (int x = -explosionRadius; x <= explosionRadius; x++)
            {
                for (int y = -explosionRadius; y <= explosionRadius; y++)
                {
                    // Verificar si la posición está dentro del rango del radio de explosión
                    if (Math.Abs(x) + Math.Abs(y) <= explosionRadius)
                    {
                        var node = GetNodeAtPosition(centerNode.X + x, centerNode.Y + y);
                        if (node != null)
                        {
                            affectedNodes.Add(node);
                        }
                    }
                }
            }

            return affectedNodes;
        }
    }
}



