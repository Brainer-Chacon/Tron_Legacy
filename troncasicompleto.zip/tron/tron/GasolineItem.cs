using System;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Controls;
using tron;

public class GasolineItem
{
    public GridNode Position { get; private set; }
    public Rectangle Visual { get; private set; }
    public int FuelValue { get; private set; } // Valor de combustible del ítem

    public GasolineItem(GridNode position)
    {
        Position = position;
        Position.IsGasolineOccupied = true; // Marca el nodo como ocupado solo para gasolina
        Visual = CreateVisual(); // Crear la representación visual de la gasolina
        UpdateVisualPosition(); // Establecer la posición inicial del visual
        FuelValue = new Random().Next(1, 16); // Asigna un valor de combustible aleatorio entre 1 y 15
    }

    private Rectangle CreateVisual()
    {
        return new Rectangle
        {
            Width = MainWindow.CellSize,
            Height = MainWindow.CellSize,
            Fill = Brushes.DeepPink, // Color de la gasolina
            Stroke = Brushes.Black,
            StrokeThickness = 1
        };
    }

    public void Respawn(GameGrid gameGrid)
    {
        // Libera el nodo actual de gasolina
        Position.IsGasolineOccupied = false; 
        Random random = new Random();
        int newRow, newCol;

        // Encuentra una nueva posición libre sin gasolina, ítems, ni motos
        do
        {
            newRow = random.Next(0, gameGrid.Rows); // Genera fila aleatoria
            newCol = random.Next(0, gameGrid.Cols); // Genera columna aleatoria
        } 
        // Verifica que la nueva posición no esté ocupada ni por gasolina, ni por ítems, ni por motos
        while (gameGrid.Grid[newRow, newCol].IsOccupied || 
               gameGrid.Grid[newRow, newCol].IsGasolineOccupied || 
               gameGrid.Grid[newRow, newCol].IsItemOccupied ||
               gameGrid.Grid[newRow, newCol].IsSpeedItemOccupied
               || gameGrid.Grid[newRow, newCol].IsShieldOccupied);  // Nueva condición

        // Asigna la nueva posición a la gasolina
        Position = gameGrid.Grid[newRow, newCol];
        Position.IsGasolineOccupied = true; // Marca la nueva posición como ocupada por gasolina
        FuelValue = random.Next(1, 16); // Asigna un nuevo valor de combustible aleatorio entre 1 y 15

        // Actualiza la posición visual de la gasolina
        UpdateVisualPosition();
    }


    public void UpdateVisualPosition()
    {
        Canvas.SetLeft(Visual, Position.Y * MainWindow.CellSize);
        Canvas.SetTop(Visual, Position.X * MainWindow.CellSize);
    }
}