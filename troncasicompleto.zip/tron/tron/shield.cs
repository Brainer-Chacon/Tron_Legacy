using System;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace tron
{
    public class Shield
    {
        public GridNode Position { get; private set; }  // Posición actual del escudo en el grid
        public TimeSpan Duration { get; private set; }  // Duración del escudo
        private DateTime activationTime;               // Momento en el que el escudo se activó
        public bool IsActive { get; set; }      // Estado del escudo (si está activo o no)
        public Rectangle Visual { get; private set; }

      

        public Shield(GridNode position)
        {
            Position = position;
            Position.IsShieldOccupied = true; // Marca el nodo como ocupado por el escudo
            Visual = CreateVisual(); // Crear la representación visual del escudo
            UpdateVisualPosition(); // Establecer la posición inicial del visual
            Duration = TimeSpan.FromSeconds(new Random().Next(5, 9)); // Asigna una duración aleatoria entre 3 y 8 segundos
            IsActive = false; // Inicialmente, el escudo no está activo
        }

        private Rectangle CreateVisual()
        {
            return new Rectangle
            {
                Width = MainWindow.CellSize,
                Height = MainWindow.CellSize,
                Fill = Brushes.Brown, // Color del escudo
                Stroke = Brushes.Black,
                StrokeThickness = 1
            };
        }

        // Método para activar el escudo
        public void Activate()
        {
            IsActive = true;
            activationTime = DateTime.Now; // Guarda el momento en que se activa el escudo
        }

        // Método para desactivar el escudo
        public void Deactivate()
        {
            IsActive = false;
        }

        // Método para verificar si el escudo sigue activo según el tiempo transcurrido
        public bool IsExpired()
        {
            if (!IsActive) return true; // Si el escudo no está activo, ya está expirado

            // Verifica si el tiempo desde la activación ha superado la duración
            return DateTime.Now - activationTime >= Duration;
        }

        // Método para mover el escudo a una nueva posición (similar al respawn)
        public void Respawn(GameGrid gameGrid)
        {
            // Libera la posición actual
            Position.IsShieldOccupied = false;

            Random random = new Random();
            int newRow, newCol;

            // Encuentra una nueva posición libre sin otros ítems, motos o gasolina
            do
            {
                newRow = random.Next(0, gameGrid.Rows);
                newCol = random.Next(0, gameGrid.Cols);
            }
            while (gameGrid.Grid[newRow, newCol].IsOccupied ||           // No debe estar ocupado por motos
                   gameGrid.Grid[newRow, newCol].IsGasolineOccupied ||   // No debe estar ocupado por gasolina
                   gameGrid.Grid[newRow, newCol].IsItemOccupied ||       // No debe estar ocupado por ítems
                   gameGrid.Grid[newRow, newCol].IsSpeedItemOccupied ||  // No debe estar ocupado por ítems de velocidad
                   gameGrid.Grid[newRow, newCol].IsShieldOccupied);      // No debe estar ocupado por otro escudo

            // Asigna la nueva posición al escudo
            Position = gameGrid.Grid[newRow, newCol];
            Position.IsShieldOccupied = true; // Marca la nueva posición como ocupada por el escudo

            // Actualiza la posición visual del escudo
            UpdateVisualPosition();
        }

        // Método para actualizar la posición visual del escudo en la interfaz gráfica
        public void UpdateVisualPosition()
        {
            // Actualiza la posición visual en el grid
            Canvas.SetLeft(Visual, Position.Y * MainWindow.CellSize);
            Canvas.SetTop(Visual, Position.X * MainWindow.CellSize);
        }
    }
}
