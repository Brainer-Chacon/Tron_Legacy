﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Diagnostics;
using System.Windows.Threading;

namespace tron
{
    public partial class MainWindow : Window
    {
        public const int CellSize = 20;
        private GameGrid gameGrid;
        private LightCycle playerLightCycle;
        private BotLightCycle[] botLightCycles;
        private DispatcherTimer gameTimer;
        private DispatcherTimer botMovementTimer;
        private List<items> items;
        private List<GasolineItem> gasolineItems; // Lista para los ítems de gasolina
        private List<Bomb> bombs;

        public List<SpeedItem> speedItems;
        private DateTime lastUpdateTime; // Tiempo del último tick
        public List<Shield> shields;

        private const int Separation = 3; // Número de celdas para separar las motos


        public MainWindow()
        {
            InitializeComponent();

            this.Loaded += MainWindow_Loaded;
            this.SizeChanged += Window_SizeChanged; // Asegúrate de que este evento esté asociado
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            InitializeGame();
            StartGame();
        }

        private void InitializeGame()
        {
            if (gameCanvas.ActualHeight > 0 && gameCanvas.ActualWidth > 0)
            {
                int rows = (int)(gameCanvas.ActualHeight / CellSize);
                int cols = (int)(gameCanvas.ActualWidth / CellSize);
                gameGrid = new GameGrid(rows, cols);

                Random random = new Random();
                int centerRow = rows / 2;
                int centerCol = cols / 2;

                // Coloca la moto del jugador en el centro
                var playerStartNode = gameGrid.Grid[centerRow, centerCol];
                playerLightCycle = new LightCycle(playerStartNode, 3, 3, gameGrid, 100);
                playerLightCycle.FuelChanged += OnFuelChanged;

                // Coloca las motos de los bots alrededor del centro
                botLightCycles = new BotLightCycle[3];
                for (int i = 0; i < botLightCycles.Length; i++)
                {
                    int botRow = centerRow + (i + 1) * Separation;
                    int botCol = centerCol + (i + 1) * Separation;
                    botRow = Math.Clamp(botRow, 0, rows - 1);
                    botCol = Math.Clamp(botCol, 0, cols - 1);
                    var botStartNode = gameGrid.Grid[botRow, botCol];

                    // Asigna un color diferente a cada bot
                    Color botColor = i switch
                    {
                        0 => Colors.Red,
                        1 => Colors.Green,
                        2 => Colors.Yellow,
                        _ => Colors.Gray
                    };

                    botLightCycles[i] = new BotLightCycle(botStartNode, 3, 3, gameGrid, new SolidColorBrush(botColor));
                }

                // Inicializa los items en posiciones aleatorias
                items = new List<items>();
                for (int i = 0; i < 10; i++) // Genera 10 items
                {
                    int itemRow, itemCol;
                    do
                    {
                        itemRow = random.Next(0, rows);
                        itemCol = random.Next(0, cols);
                    } while (gameGrid.Grid[itemRow, itemCol].IsOccupied); // Asegura que la posición no esté ocupada

                    var item = new items(gameGrid.Grid[itemRow, itemCol]);
                    items.Add(item);
                }

                shields = new List<Shield>();
                for (int i = 0; i < 7; i++) // Genera 10 items
                {
                    int shieldRow, shieldCol;
                    do
                    {
                        shieldRow = random.Next(0, rows);
                        shieldCol = random.Next(0, cols);
                    } while (gameGrid.Grid[shieldRow, shieldCol].IsOccupied); // Asegura que la posición no esté ocupada

                    var item = new Shield(gameGrid.Grid[shieldRow, shieldCol]);
                    shields.Add(item);
                }

                // Crear y agregar los ítems de gasolina al grid
                gasolineItems = new List<GasolineItem>();
                for (int i = 0; i < 10; i++) // Genera 10 items
                {
                    int gasolineItemsRow, gasolineItemsCol;
                    do
                    {
                        gasolineItemsRow = random.Next(0, rows);
                        gasolineItemsCol = random.Next(0, cols);
                    } while (gameGrid.Grid[gasolineItemsRow, gasolineItemsCol]
                             .IsOccupied); // Asegura que la posición no esté ocupada

                    var gasolineitems = new GasolineItem(gameGrid.Grid[gasolineItemsRow, gasolineItemsCol]);
                    gasolineItems.Add(gasolineitems);
                }

                speedItems = new List<SpeedItem>();
                for (int i = 0; i < 10; i++) // Genera 10 items
                {
                    int speedItemsRow, speedItemsCol;
                    do
                    {
                        speedItemsRow = random.Next(0, rows);
                        speedItemsCol = random.Next(0, cols);
                    } while (gameGrid.Grid[speedItemsRow, speedItemsCol]
                             .IsOccupied); // Asegura que la posición no esté ocupada

                    var speeditems = new SpeedItem(gameGrid.Grid[speedItemsRow, speedItemsCol]);
                    speedItems.Add(speeditems);
                }

                bombs = new List<Bomb>();
                for (int i = 0; i < 10; i++) // Genera 10 items
                {
                    int bombItemsRow, bombItemsCol;
                    do
                    {
                        bombItemsRow = random.Next(0, rows);
                        bombItemsCol = random.Next(0, cols);
                    } while (gameGrid.Grid[bombItemsRow, bombItemsCol]
                             .IsOccupied); // Asegura que la posición no esté ocupada

                    var bombitems = new Bomb(gameGrid.Grid[bombItemsRow, bombItemsCol], gameGrid);
                    bombs.Add(bombitems);
                }



                DrawGrid();
                DrawLightCycles();
                DrawItems(); // Llama al método que dibuja los items
                DrawBomb();
                DrawShields();
            }
            else
            {
                MessageBox.Show("El tamaño del canvas es inválido.", "Error de Inicialización", MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }



        private void CheckMotoCollisions(LightCycle player, List<BotLightCycle> bots)
        {
            // Verificar si el jugador colisiona con cualquier bot
            foreach (var bot in bots)
            {
                if (IsCollision(player, bot))
                {
                    // Si el jugador tiene un escudo, no eliminar la moto
                    if (!player.IsInvulnerable)
                    {
                        player.EliminateLightCycle();
                        player.IsActive = false;
                        Debug.WriteLine("¡Colisión detectada entre el jugador y un bot!");
                    }
                    // Si el bot tiene un escudo, no eliminar la moto
                    if (!bot.IsInvulnerable)
                    {
                        bot.EliminateLightCycle();
                        bot.IsActive = false;
                    }
                    break; // Romper el bucle después de detectar una colisión
                }
            }

            // Verificar colisiones entre los bots
            for (int i = 0; i < bots.Count; i++)
            {
                for (int j = i + 1; j < bots.Count; j++) // Verificar solo los bots siguientes para evitar duplicaciones
                {
                    if (IsCollision(bots[i], bots[j]))
                    {
                        // Si ambos bots tienen escudo, no eliminarlos
                        if (!bots[i].IsInvulnerable && !bots[j].IsInvulnerable)
                        {
                            bots[i].EliminateLightCycle();
                            bots[j].EliminateLightCycle();
                            bots[j].IsActive = false;
                            
                            Debug.WriteLine("¡Colisión detectada entre dos bots!");
                        }
                        break; // Romper el bucle después de detectar una colisión
                    }
                }
            }
        }


        private bool IsCollision(LightCycle lightCycle1, BotLightCycle lightCycle2)
        {
            // Verificar si cualquier parte de la estela (Trail) de lightCycle1 está en el mismo nodo que cualquier parte de la estela de lightCycle2
            foreach (var node1 in lightCycle1.Trail)
            {
                foreach (var node2 in lightCycle2.Trail)
                {
                    if (node1 == node2) // Compara si ambos nodos son el mismo
                    {
                        return true; // Colisión detectada
                    }
                }
            }

            return false; // No hay colisión
        }


        private void DrawGrid()
        {
            gameCanvas.Children.Clear();

            if (gameCanvas.ActualWidth > 0 && gameCanvas.ActualHeight > 0)
            {
                for (int i = 0; i < gameGrid.Rows; i++)
                {
                    for (int j = 0; j < gameGrid.Cols; j++)
                    {
                        var node = gameGrid.Grid[i, j];

                        Rectangle rect = new Rectangle
                        {
                            Width = CellSize,
                            Height = CellSize,
                            Stroke = Brushes.Black,
                            Fill = node.IsOccupied ? Brushes.Red : Brushes.White
                        };

                        Canvas.SetLeft(rect, j * CellSize);
                        Canvas.SetTop(rect, i * CellSize);

                        gameCanvas.Children.Add(rect);
                    }
                }
            }
        }

        private void DrawLightCycles()
        {
            // Dibuja la moto del jugador
            foreach (var node in playerLightCycle.Trail)
            {
                Rectangle rect = new Rectangle
                {
                    Width = CellSize,
                    Height = CellSize,
                    Fill = Brushes.Blue
                };

                Canvas.SetLeft(rect, node.Y * CellSize);
                Canvas.SetTop(rect, node.X * CellSize);

                gameCanvas.Children.Add(rect);
            }

            // Dibuja las motos de los bots
            foreach (var bot in botLightCycles)
            {
                foreach (var node in bot.Trail)
                {
                    Rectangle rect = new Rectangle
                    {
                        Width = CellSize,
                        Height = CellSize,
                        Fill = bot.Color // Usa el Brush aquí
                    };

                    Canvas.SetLeft(rect, node.Y * CellSize);
                    Canvas.SetTop(rect, node.X * CellSize);

                    gameCanvas.Children.Add(rect);
                }
            }
        }

        public void DrawItems()
        {
            foreach (var item in items)
            {
                // Verificar si el ítem ya está en el Canvas antes de agregarlo
                if (!gameCanvas.Children.Contains(item.Visual))
                {
                    gameCanvas.Children.Add(item.Visual);
                }

                // Actualizar la posición del ítem en el Canvas
                item.UpdateVisualPosition();
            }
        }

        public void DrawShields()
        {
            foreach (var shield in shields) // Asumiendo que tienes una lista de escudos llamada 'shields'
            {
                // Verificar si el escudo ya está en el Canvas antes de agregarlo
                if (!gameCanvas.Children.Contains(shield.Visual))
                {
                    gameCanvas.Children.Add(shield.Visual);
                }

                // Actualizar la posición del escudo en el Canvas
                shield.UpdateVisualPosition();
            }
        }

        public void DrawBomb()
        {
            foreach (var item in bombs)
            {
                // Verificar si el ítem ya está en el Canvas antes de agregarlo
                if (!gameCanvas.Children.Contains(item.Visual))
                {
                    gameCanvas.Children.Add(item.Visual);
                }

                // Actualizar la posición del ítem en el Canvas
                item.UpdateVisualPosition();
            }
        }

        public void DrawGasolineItems()
        {
            foreach (var item in gasolineItems)
            {
                // Verificar si el ítem ya está en el Canvas antes de agregarlo
                if (!gameCanvas.Children.Contains(item.Visual))
                {
                    gameCanvas.Children.Add(item.Visual);
                }

                // Actualizar la posición del ítem en el Canvas
                item.UpdateVisualPosition();
            }
        }

        public void DrawSpeedItems()
        {
            foreach (var item in speedItems)
            {
                // Verificar si el ítem ya está en el Canvas antes de agregarlo
                if (!gameCanvas.Children.Contains(item.Visual))
                {
                    gameCanvas.Children.Add(item.Visual);
                }

                // Actualizar la posición del ítem en el Canvas
                item.UpdateVisualPosition();
            }
        }


        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            Direction newDirection;



            switch (e.Key)
            {
                case Key.Up:
                    newDirection = Direction.Up;
                    break;
                case Key.Down:
                    newDirection = Direction.Down;
                    break;
                case Key.Left:
                    newDirection = Direction.Left;
                    break;
                case Key.Right:
                    newDirection = Direction.Right;
                    break;
                default:
                    return;
            }

            // Verifica que la nueva dirección no sea opuesta a la actual
            if (playerLightCycle.CanChangeDirection(newDirection))
            {
                playerLightCycle.CurrentDirection = newDirection;
            }

        }

        private void Window_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            if (gameCanvas != null && gameCanvas.ActualHeight > 0 && gameCanvas.ActualWidth > 0)
            {
                int newRows = (int)(gameCanvas.ActualHeight / CellSize);
                int newCols = (int)(gameCanvas.ActualWidth / CellSize);

                if (gameGrid == null || gameGrid.Rows != newRows || gameGrid.Cols != newCols)
                {
                    gameGrid = new GameGrid(newRows, newCols);
                    InitializeGame();
                }
            }
            else
            {
                Debug.WriteLine("Canvas no está inicializado o tiene un tamaño inválido.");
            }
        }

        public void CheckItemCollisions()
        {
            foreach (var item in items.ToList())
            {
                // Verificar si la estela de la moto del jugador toca un ítem
                if (playerLightCycle.Trail.Contains(item.Position))
                {


                    List<GridNode> nodesAffected;
                    bool trailIncreased = playerLightCycle.AdjustTrailLengthRandomly(out nodesAffected);



                    // Reubica el ítem y elimina del canvas
                    item.Respawn(gameGrid);
                    gameCanvas.Children.Remove(item.Visual);
                    DrawItems(); // Redibuja los items después de la reubicación

                    // Si la estela se ha reducido, elimina los nodos del grid
                    if (!trailIncreased)
                    {
                        gameGrid.RemoveNodesFromGrid(nodesAffected);
                    }
                }

                // Verificar si las estelas de las motos de los bots tocan un ítem
                foreach (var bot in botLightCycles)
                {
                    if (bot.Trail.Contains(item.Position))
                    {


                        List<GridNode> nodesAffected;
                        bool trailIncreased = bot.AdjustTrailLengthRandomly(out nodesAffected);



                        // Reubica el ítem y elimina del canvas
                        item.Respawn(gameGrid);
                        gameCanvas.Children.Remove(item.Visual);
                        DrawItems(); // Redibuja los items después de la reubicación

                        // Si la estela se ha reducido, elimina los nodos del grid
                        if (!trailIncreased)
                        {
                            gameGrid.RemoveNodesFromGrid(nodesAffected);
                        }
                    }
                }
            }
        }

        public void CheckGasolineCollisions()
        {
            foreach (var gasolineItem in gasolineItems.ToList())
            {
                // Verificar si la estela de la moto del jugador toca un ítem de gasolina
                if (playerLightCycle.Trail.Contains(gasolineItem.Position))
                {
                    // Incrementar el combustible del jugador
                    int newFuel = playerLightCycle.Fuel + gasolineItem.FuelValue;
                    playerLightCycle.Fuel = Math.Min(newFuel, 100); // Asegúrate de que el combustible no supere 100




                    // Reubica el ítem de gasolina y elimina del canvas
                    gasolineItem.Respawn(gameGrid);
                    gameCanvas.Children.Remove(gasolineItem.Visual);
                    DrawGasolineItems();
                }

                // Verificar si las estelas de las motos de los bots tocan un ítem de gasolina
                foreach (var bot in botLightCycles)
                {
                    if (bot.Trail.Contains(gasolineItem.Position))
                    {
                        // Incrementar el combustible del bot
                        int newFuel = bot.Fuel + gasolineItem.FuelValue;
                        bot.Fuel = Math.Min(newFuel, 100); // Asegúrate de que el combustible no supere 100




                        // Reubica el ítem de gasolina y elimina del canvas
                        gasolineItem.Respawn(gameGrid);
                        gameCanvas.Children.Remove(gasolineItem.Visual);
                        DrawGasolineItems();
                    }
                }
            }
        }

        public void CheckSpeedItemCollisions()
        {
            foreach (var speedItem in speedItems.ToList())
            {
                // Verificar si la estela de la moto del jugador toca un ítem de velocidad
                if (playerLightCycle.Trail.Contains(speedItem.Position))
                {
                    // Solo aplicar si no hay un boost activo
                    if (playerLightCycle.boostDuration <= 0)
                    {
                        playerLightCycle.ApplySpeedBoost(speedItem.SpeedValue, speedItem.boostDuration);

                        // Reubicar el ítem de velocidad y eliminar del canvas
                        speedItem.Respawn(gameGrid);
                        gameCanvas.Children.Remove(speedItem.Visual);
                        DrawSpeedItems();
                    }
                }

                // Verificar si las estelas de las motos de los bots tocan un ítem de velocidad
                foreach (var bot in botLightCycles)
                {
                    if (bot.Trail.Contains(speedItem.Position))
                    {
                        // Solo aplicar si no hay un boost activo
                        if (bot.boostDuration <= 0)
                        {
                            bot.ApplySpeedBoost(speedItem.SpeedValue, speedItem.boostDuration);

                            // Reubicar el ítem de velocidad y eliminar del canvas
                            speedItem.Respawn(gameGrid);
                            gameCanvas.Children.Remove(speedItem.Visual);
                            DrawSpeedItems();
                        }
                    }
                }
            }
        }

        public void CheckBombCollisions()
        {
            foreach (var bomb in bombs.ToList())
            {
                // Verificar si la estela de la moto del jugador toca una bomba
                if (playerLightCycle.Trail.Contains(bomb.Position))
                {
                    // Solo eliminar la moto del jugador si no está invulnerable
                    if (!playerLightCycle.IsInvulnerable)
                    {
                        playerLightCycle.EliminateLightCycle();
                        playerLightCycle.IsActive = false;
                    }

                    // Mostrar efectos de explosión y eliminar la bomba
                    bomb.Explode();

                    // Eliminar la bomba del canvas y reubicarla
                    gameCanvas.Children.Remove(bomb.Visual);
                    bomb.Respawn(gameGrid);
                    DrawBomb(); // Si estás usando un método para volver a dibujar las bombas
                }

                // Verificar si las estelas de las motos de los bots tocan una bomba
                foreach (var bot in botLightCycles)
                {
                    if (bot.Trail.Contains(bomb.Position))
                    {
                        // Solo eliminar la moto del bot si no está invulnerable
                        if (!bot.IsInvulnerable)
                        {
                            bot.EliminateLightCycle();
                            bot.IsActive = false;
                        }

                        // Mostrar efectos de explosión y eliminar la bomba
                        bomb.Explode();

                        // Eliminar la bomba del canvas y reubicarla
                        gameCanvas.Children.Remove(bomb.Visual);
                        bomb.Respawn(gameGrid);
                        DrawBomb(); // Si estás usando un método para volver a dibujar las bombas
                    }
                }
            }
        }




        private void OnFuelChanged(int newFuel)
        {
            // Actualiza el TextBlock FuelText con el nuevo nivel de combustible
            Dispatcher.Invoke(() => { FuelText.Text = $"Combustible: {newFuel}"; });
        }

        public void CheckShieldCollisions()
        {
            foreach (var shield in shields.ToList())
            {
                // Verificar si la estela de la moto del jugador toca un escudo
                if (playerLightCycle.Trail.Contains(shield.Position) && !playerLightCycle.IsInvulnerable && playerLightCycle.Shield == null)
                {
                    // Guardar el escudo en la moto del jugador
                    playerLightCycle.Shield = shield; // Asumiendo que tienes una propiedad para el escudo
                    shield.Respawn(gameGrid); // Reubicar el escudo en el grid

                    // Eliminar el escudo del canvas
                    gameCanvas.Children.Remove(shield.Visual);
                    DrawShields(); // Volver a dibujar el escudo si es necesario
                }

                // Verificar si las estelas de las motos de los bots tocan un escudo
                foreach (var bot in botLightCycles)
                {
                    if (bot.Trail.Contains(shield.Position) && !bot.IsInvulnerable && bot.Shield == null)
                    {
                        // Guardar el escudo en el bot
                        bot.Shield = shield; // Asumiendo que también tienes una propiedad para el escudo
                        shield.Respawn(gameGrid); // Reubicar el escudo en el grid

                        // Eliminar el escudo del canvas
                        gameCanvas.Children.Remove(shield.Visual);
                        DrawShields(); // Volver a dibujar el escudo si es necesario
                    }
                }
            }
        }


        public void Update()
        {
            // Actualizar el texto de poderes
            if (playerLightCycle.Shield != null)
            {
                PowerText.Text = "Poderes: Escudo Activo";
            }
            else
            {
                PowerText.Text = "Poderes: Ninguno";
            }

            // Manejar el escudo del jugador
            if (Keyboard.IsKeyDown(Key.Space) && playerLightCycle.Shield != null)
            {
                playerLightCycle.ActivateShield(playerLightCycle.Shield); // Activa el escudo
                playerLightCycle.Shield = null; // Limpiar el escudo después de usarlo
                PowerText.Text = "Poderes: Ninguno"; // Actualizar texto al usar el escudo
            }

            // Lógica para los bots para activar el escudo automáticamente
            foreach (var bot in botLightCycles)
            {
                if (bot.Shield != null && !bot.IsInvulnerable)
                {
                    bot.ActivateShield(bot.Shield); // Activa el escudo
                    bot.Shield = null; // Limpiar el escudo después de usarlo
                }
            }
        }


        private void ActivateShieldWithTimer(BotLightCycle bot)
        {
            if (bot.Shield != null)
            {
                bot.ActivateShield(bot.Shield); // Activa el escudo
                bot.Shield = null; // Limpiar el escudo

                // Configurar un temporizador para desactivar el escudo después de la duración
                var timer = new DispatcherTimer { Interval = bot.Shield.Duration };
                timer.Tick += (s, e) =>
                {
                    bot.DeactivateShield();
                    timer.Stop();
                };
                timer.Start();
            }
        }

        private void CheckForWinner()
        {
            int activeCount = 0;
            Color winnerColor = Colors.Transparent;

            // Contar las motos activas
            foreach (var bot in botLightCycles)
            {
                if (bot.IsActive) // Asegúrate de tener una propiedad que indique si la moto está activa
                {
                    activeCount++;
                    
                }
            }

            // Contar la moto del jugador
            if (playerLightCycle.IsActive) // Igual aquí
            {
                activeCount++;
                winnerColor = Colors.Blue; // Asumiendo que la moto del jugador es azul
            }

            // Si solo hay una moto activa, declarar al ganador
            if (activeCount == 1)
            {
                ShowWinnerMessage(winnerColor);
                EndGame(); // Detener el juego si es necesario
            }
        }

        private void ShowWinnerMessage(Color winnerColor)
        {
            string message;

            if (winnerColor == Colors.Blue)
            {
                message = "¡El jugador ha ganado!";
            }
            else
            {
                message = $"¡los bots han ganado!";
            }

            MessageBox.Show(message, "Fin del Juego", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void EndGame()
        {
            
            this.Close(); // Cierra la ventana principal
        }



        private void StartGame()
        {
            gameTimer = new DispatcherTimer();
            gameTimer.Interval = TimeSpan.FromMilliseconds(100); // Ajusta el intervalo según sea necesario
            gameTimer.Tick += (s, e) =>
            {
                double deltaTime = gameTimer.Interval.TotalSeconds; // Tiempo entre ticks

                // Actualiza el estado de la moto del jugador
                playerLightCycle.Update(deltaTime);
                playerLightCycle.Move(); // Movimiento del jugador

                // Actualiza el estado de los bots
                foreach (var bot in botLightCycles)
                {
                    bot.Update(deltaTime); // Actualiza el estado de los bots
                    bot.Move(); // Movimiento de los bots

                    // Verificar si el bot tiene un escudo y activarlo
                    if (bot.Shield != null && !bot.IsInvulnerable)
                    {
                        ActivateShieldWithTimer(bot); // Activa el escudo del bot
                    }
                }

                // Verificar colisiones entre las motos (jugador y bots)
                CheckMotoCollisions(playerLightCycle, botLightCycles.ToList());

                // Verificar colisiones con otros objetos
                CheckItemCollisions(); // Verifica las colisiones con los items
                CheckGasolineCollisions(); // Verifica colisiones con gasolina
                CheckSpeedItemCollisions(); // Verifica colisiones con ítems de velocidad
                CheckBombCollisions(); // Verifica colisiones con bombas
                CheckShieldCollisions(); // Verifica colisiones con escudos
                CheckForWinner();

                // Actualiza el estado de escudos
                Update(); // Llama al método Update aquí

                // Dibuja el estado actualizado
                DrawGrid();
                DrawLightCycles();
                DrawItems();
                DrawGasolineItems();
                DrawSpeedItems();
                DrawBomb();
                DrawShields();
            };

            gameTimer.Start();
        }

    }
}
