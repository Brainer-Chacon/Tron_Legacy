using System;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Controls;
using tron;

public class items
{
    public GridNode Position { get; private set; }
    public int Value { get; private set; }
    public Rectangle Visual { get; private set; }
    public bool IsFuelItem { get; private set; } // Nuevo campo para ítems de gasolina


    public items(GridNode position, bool isFuelItem = false)
    {
        Position = position;
        Value = new Random().Next(1, 11); // Valor aleatorio entre 1 y 10
        Position.IsOccupied = false; // Marca el nodo como ocupado por el ítem
        Visual = CreateVisual(); // Crear la representación visual del ítem
        UpdateVisualPosition(); // Establecer la posición inicial del visual\
        IsFuelItem = isFuelItem;
       
       
    }

    private Rectangle CreateVisual()
    {
        return new Rectangle
        {
            Width = MainWindow.CellSize,
            Height = MainWindow.CellSize,
            Fill = Brushes.Purple, // Color del ítem
            Stroke = Brushes.Black,
            StrokeThickness = 1
        };
    }

    public void Respawn(GameGrid gameGrid)
    {
        // Libera la posición actual
        Position.IsOccupied = false; 
    
        Random random = new Random();
        int newRow, newCol;

        // Encuentra una nueva posición libre, sin ítems ni gasolina
        do
        {
            newRow = random.Next(0, gameGrid.Rows); // Genera fila aleatoria
            newCol = random.Next(0, gameGrid.Cols); // Genera columna aleatoria
        } 
        // Verifica que la nueva posición no esté ocupada ni por otro ítem ni por gasolina
        while (gameGrid.Grid[newRow, newCol].IsOccupied || gameGrid.Grid[newRow, newCol].IsGasolineOccupied || gameGrid.Grid[newRow, newCol].IsItemOccupied ||
               gameGrid.Grid[newRow, newCol].IsSpeedItemOccupied || gameGrid.Grid[newRow, newCol].IsShieldOccupied);

        // Actualiza la nueva posición
        Position = gameGrid.Grid[newRow, newCol];
        Position.IsOccupied = false; // Marca la nueva posición como ocupada

        // Asigna un nuevo valor aleatorio (puedes ajustar este valor según tu lógica)
        Value = random.Next(1, 11);

        // Actualiza la posición visual del ítem
        UpdateVisualPosition();
    }


    public void UpdateVisualPosition()
    {
        Canvas.SetLeft(Visual, Position.Y * MainWindow.CellSize);
        Canvas.SetTop(Visual, Position.X * MainWindow.CellSize);
    }
}

