using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Windows.Threading;
using tron;

public enum Direction
{
    Up,
    Down,
    Left,
    Right
}

public class LightCycle
{
    public LinkedList<GridNode> Trail { get; private set; }
    public bool IsInvulnerable { get; private set; } // Indicador de invulnerabilidad
    private DispatcherTimer shieldTimer; // Temporizador para el escudo
    private TimeSpan shieldDuration; // Duración restante del escudo
    private DispatcherTimer blinkTimer; // Temporizador para el parpadeo
    private bool isBlinking; // Indica si la moto está parpadeando
    public event Action<int> FuelChanged;
   

    public Shield Shield { get; set; }
    public int Fuel { get; set; } // Valor de 0 a 100
    private int cellsTraveled; // Contador de celdas recorridas
    private bool isSpeedBoostActive; // Indica si hay un "boost" de velocidad activo
    private DispatcherTimer speedBoostTimer;
    public int Speed { get; set; } = 1; // Velocidad inicial por defecto
    private double timeSinceLastMove; // Tiempo transcurrido desde el último movimiento
    public double boostDuration { get; private set; } = 0; 
    private int normalSpeed = 1; // Velocidad normal
    private List<Bomb> _bombs; // Lista de bombas en el juego
   
    public bool IsActive { get; set; }


    public Direction CurrentDirection { get; set; }
    public GridNode CurrentNode => Trail.First?.Value;

    private int _maxTrailLength;
    protected GameGrid _gameGrid;

    public LightCycle(GridNode startNode, int initialTrailLength, int maxTrailLength, GameGrid gameGrid, int initialFuel)
    {
        Trail = new LinkedList<GridNode>();
        _maxTrailLength = maxTrailLength;
        _gameGrid = gameGrid;
        Fuel = initialFuel; // Inicia con combustible
        cellsTraveled = 0;  // Inicializa el contador de celdas recorridas
        IsActive=true;
        
        
        for (int i = 0; i < initialTrailLength; i++)
        {
            Trail.AddLast(startNode);
        }

        foreach (var node in Trail)
        {
            node.IsOccupied = true;
        }
    }

    private void OnFuelChanged()
    {
        FuelChanged?.Invoke(Fuel);
    }

    // Método que se llama en cada tick del temporizador
    public void Update(double deltaTime)
    {
        // Si hay un boost activo, reduce su duración
        if (boostDuration > 0)
        {
            boostDuration -= deltaTime;
            if (boostDuration <= 0)
            {
                Speed = normalSpeed; // Restaura la velocidad normal una vez que el boost termina
            }
        }

        timeSinceLastMove += deltaTime;

        // Calcula el intervalo de movimiento en función de la velocidad actual
        double moveInterval = 1.0 / Speed;

        if (timeSinceLastMove >= moveInterval)
        {
            Move(); // Llama al método de movimiento
            timeSinceLastMove = 0; // Reinicia el contador de tiempo
        }
    }

    // Método para aplicar un boost temporal de velocidad
    public void ApplySpeedBoost(int newSpeed, double duration)
    {
        Speed = newSpeed;
        boostDuration = duration; // Aplica el boost por la duración dada
    }

    public virtual void Move()
    {
        // Verifica si el combustible es suficiente para moverse
        if (Fuel <= 0)
        {
            Debug.WriteLine("La moto se ha quedado sin combustible y no puede moverse.");
            return;
        }

        // Obtiene el siguiente nodo en la dirección actual
        GridNode nextNode = GetNextNode(CurrentDirection);

        // Verifica si el siguiente nodo es null
        if (nextNode == null)
        {
            Debug.WriteLine("El siguiente nodo es null.");

            // Verifica si la moto está cerca de una bomba antes de eliminarla
            if (IsNearBomb())
            {
                Debug.WriteLine("La moto está cerca de una bomba. Eliminando la moto.");
                EliminateLightCycle(); // Elimina la moto de forma segura
            }
            return;
        }

        if (nextNode.Item != null || true)  // Simplemente permitimos el movimiento
        {
            // Añade el nuevo nodo a la estela
            Trail.AddFirst(nextNode);
            nextNode.IsOccupied = true;  // Esto sigue siendo necesario para mostrar la estela

            // Mantiene la longitud de la estela
            if (Trail.Count > _maxTrailLength)
            {
                GridNode oldestNode = Trail.Last.Value;
                oldestNode.IsOccupied = false;
                Trail.RemoveLast();
            }

            // Incrementa el contador de celdas recorridas
            cellsTraveled++;
            Debug.WriteLine("Se añade una celda recorrida.");

            // Reduce el combustible cada 5 celdas recorridas
            if (cellsTraveled == 5)
            {
                ReduceFuel(1);
                OnFuelChanged(); // Notifica que el combustible ha cambiado
                cellsTraveled = 0; // Reinicia el contador de celdas recorridas
            }
        }
    }

    public void EliminateLightCycle()
    {
        // Lista para almacenar nodos que serán desocupados
        List<GridNode> nodesToRemove = new List<GridNode>(Trail);

        // Elimina la moto de la estela
        Trail.Clear();

        // Desocupa todos los nodos de la estela
        foreach (var node in nodesToRemove)
        {
            if (node != null)
            {
                node.IsOccupied = false; // Marca el nodo como no ocupado
            }
        }

        // Realiza otras acciones necesarias para eliminar la moto, si es necesario
        Debug.WriteLine("Moto eliminada y estela limpiada.");
    }

    public bool CanChangeDirection(Direction newDirection)
    {
        // Previene que la dirección cambie a la opuesta
        return !(CurrentDirection == Direction.Up && newDirection == Direction.Down ||
                 CurrentDirection == Direction.Down && newDirection == Direction.Up ||
                 CurrentDirection == Direction.Left && newDirection == Direction.Right ||
                 CurrentDirection == Direction.Right && newDirection == Direction.Left);
    }

    public GridNode GetNextNode(Direction direction)
    {
        // Verifica si Trail es null o está vacío
        if (Trail == null || !Trail.Any())
        {
            return null; // O lanzar una excepción específica si prefieres
        }

        var currentNode = Trail.First.Value;
        if (currentNode == null)
        {
            throw new InvalidOperationException("El nodo actual es null.");
        }

        int currentRow = currentNode.X;
        int currentColumn = currentNode.Y;

        if (_gameGrid == null)
        {
            throw new InvalidOperationException("gameGrid no está inicializado.");
        }

        GridNode nextNode = null;

        switch (direction)
        {
            case Direction.Up:
                nextNode = _gameGrid.GetNodeAtPosition(currentRow - 1, currentColumn);
                break;
            case Direction.Down:
                nextNode = _gameGrid.GetNodeAtPosition(currentRow + 1, currentColumn);
                break;
            case Direction.Left:
                nextNode = _gameGrid.GetNodeAtPosition(currentRow, currentColumn - 1);
                break;
            case Direction.Right:
                nextNode = _gameGrid.GetNodeAtPosition(currentRow, currentColumn + 1);
                break;
        }

        return nextNode;
    }

    public bool AdjustTrailLengthRandomly(out List<GridNode> nodesAffected)
    {
        Random random = new Random();
        int randomNumber = random.Next(1, 101);

        nodesAffected = new List<GridNode>();
        bool increased = false;

        if (randomNumber % 2 == 0) // Si el número es par
        {
            increased = IncreaseTrailLength(randomNumber % 10 + 1, nodesAffected);
        }
        else // Si el número es impar
        {
            increased = DecreaseTrailLength(randomNumber % 10 + 1, nodesAffected);
        }

        return increased;
    }

    public bool IncreaseTrailLength(int value, List<GridNode> nodesAffected)
    {
        if (value > 0)
        {
            if (Trail.Count + value > 10)
            {
                value = 10 - Trail.Count;
            }

            for (int i = 0; i < value; i++)
            {
                var lastNode = Trail.LastOrDefault();
                GridNode newNode;
                if (lastNode != null)
                {
                    newNode = new GridNode(lastNode.X, lastNode.Y);
                }
                else
                {
                    newNode = new GridNode(0, 0); 
                }

                Trail.AddLast(newNode);
                nodesAffected.Add(newNode);
            }
            return true;
        }
        return false;
    }

    public bool DecreaseTrailLength(int value, List<GridNode> nodesAffected)
    {
        if (value > 0)
        {
            if (Trail.Count - value < 1)
            {
                value = Trail.Count - 1;
            }

            for (int i = 0; i < value; i++)
            {
                var nodeToRemove = Trail.LastOrDefault();
                if (nodeToRemove != null)
                {
                    nodesAffected.Add(nodeToRemove);
                    Trail.RemoveLast();
                }
            }
            return true;
        }
        return false;
    }

 

    private void ReduceFuel(int amount)
    {
        Fuel -= amount;
        if (Fuel < 0) Fuel = 0; // Asegúrate de que el combustible no baje de 0
    }

    private bool IsNearBomb()
    {
        // Verifica si la moto está cerca de alguna bomba en la lista
        if (_bombs == null || !_bombs.Any())
        {
            return false;
        }

        var currentPosition = Trail.First?.Value;
        if (currentPosition == null)
        {
            return false;
        }

        foreach (var bomb in _bombs)
        {
            if (Math.Abs(currentPosition.X - bomb.Position.X) <= 1 && Math.Abs(currentPosition.Y - bomb.Position.Y) <= 1)
            {
                return true; // La moto está cerca de una bomba
            }
        }
        return false;
    }

    public void ActivateShield(Shield shield)
    {
        IsInvulnerable = true; // Activa la invulnerabilidad
        shieldDuration = shield.Duration; // Usa la duración del escudo

        shieldTimer = new DispatcherTimer();
        shieldTimer.Interval = TimeSpan.FromSeconds(1);
        shieldTimer.Tick += (sender, e) =>
        {
            shieldDuration -= TimeSpan.FromSeconds(1);
            if (shieldDuration <= TimeSpan.Zero)
            {
                DeactivateShield(); // Desactiva el escudo al finalizar el tiempo
            }
        };
        shieldTimer.Start();
    }


    public void DeactivateShield()
    {
        IsInvulnerable = false; // Desactiva la invulnerabilidad
        shieldTimer?.Stop(); // Detiene el temporizador
        shieldTimer = null; // Limpia la referencia al temporizador
    }

    
}

