using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Controls;

namespace tron;

public class SpeedItem
{
    public GridNode Position { get; private set; }
    public Rectangle Visual { get; private set; }
    public int SpeedValue { get; private set; } // Valor de velocidad del ítem
    public int boostDuration { get; private set; } // Duración del efecto de velocidad en segundos

    public SpeedItem(GridNode position)
    {
        Position = position;
        Position.IsSpeedItemOccupied = true; // Marca el nodo como ocupado por velocidad
        Visual = CreateVisual(); // Crear la representación visual del ítem de velocidad
        UpdateVisualPosition(); // Establecer la posición inicial del visual
        SpeedValue = new Random().Next(1, 11); // Asigna un valor de velocidad aleatorio entre 1 y 10
        boostDuration = new Random().Next(3, 9); // Asigna una duración aleatoria entre 3 y 8 segundos
    }

    private Rectangle CreateVisual()
    {
        return new Rectangle
        {
            Width = MainWindow.CellSize,
            Height = MainWindow.CellSize,
            Fill = Brushes.DarkOrange, // Color del ítem de velocidad
            Stroke = Brushes.Black,
            StrokeThickness = 1
        };
    }

    public void Respawn(GameGrid gameGrid)
    {
        // Libera la posición actual
        Position.IsSpeedItemOccupied = false;

        Random random = new Random();
        int newRow, newCol;

        // Encuentra una nueva posición libre sin ítems, gasolina o motos
        do
        {
            newRow = random.Next(0, gameGrid.Rows);
            newCol = random.Next(0, gameGrid.Cols);
        }
        while (gameGrid.Grid[newRow, newCol].IsOccupied ||
               gameGrid.Grid[newRow, newCol].IsGasolineOccupied ||
               gameGrid.Grid[newRow, newCol].IsItemOccupied ||
               gameGrid.Grid[newRow, newCol].IsSpeedItemOccupied ||
               gameGrid.Grid[newRow, newCol].IsShieldOccupied); 

        // Asigna la nueva posición al ítem de velocidad
        Position = gameGrid.Grid[newRow, newCol];
        Position.IsSpeedItemOccupied = true; // Marca la nueva posición como ocupada por velocidad
        SpeedValue = random.Next(1, 11); // Asigna un nuevo valor de velocidad aleatorio
        boostDuration = random.Next(3, 9); // Asigna una nueva duración aleatoria

        // Actualiza la posición visual del ítem
        UpdateVisualPosition();
    }


    public void UpdateVisualPosition()
    {
        Canvas.SetLeft(Visual, Position.Y * MainWindow.CellSize);
        Canvas.SetTop(Visual, Position.X * MainWindow.CellSize);
    }
}

